######################################
### PDF Reader
######################################

LINUX
$pkg install unzip
$pkg install git
$git clone url
unzip pdf-reader.zip
cd pdf-reader
######################################

Example folders with files(pdf):
/Files/pdf.pdf
/pdf-reader/pdf.pdf
...
######################################
#########USING THIS FILES
######################################


HOW TO USE IT ON #localhost
> /pdf-reader/pdf.pdf 
pdf-reader/viewer.html?url={name-pdf}

> /Files/pdf.pdf
If you added the pdf inside of pdf-reader folder will work, else use :
pdf-reader/viewer.html?url=../Files/{name-pdf}
==>pdf-reader/viewer.html?url=../Files/pdf.pdf


HOW TO USE IT ON when #hosted on ssl...
pdf-reader/viewer.html?url={your-pdf-direct-url}


######################################
#################USING THIS ONLY URL
######################################

https://client-111.web.app/pdf-reader/viewer.html?url={your-pdf-direct-url}


Example of pdf-direct-url
https://client-111.web.app/pdf.pdf

Sample:
https://client-111.web.app/pdf-reader/viewer.html?url=https://client-111.web.app/pdf.pdf
######################################
See https://github.com/mozilla/pdf.js for learning and contributing.